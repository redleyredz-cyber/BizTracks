
# Sistem Laporan Usahawan PPPK

Aplikasi pengurusan laporan bulanan usahawan yang menyokong fungsi PWA (Installable) dan integrasi Google Sheets.

## Cara Publish ke GitHub & Vercel

1. **Cipta Repository**: Pergi ke GitHub dan cipta repository baru bernama `laporan-pppk`.
2. **Upload Fail**:
   - Jika guna komputer: Letakkan semua fail ini dalam satu folder.
   - Buka laman GitHub repository anda, tekan **"Add file"** > **"Upload files"**.
   - Tarik (Drag) semua fail & folder ke dalam GitHub (Kecuali folder `node_modules` jika ada).
3. **Connect ke Vercel**:
   - Login ke [Vercel](https://vercel.com).
   - Tekan **"Add New"** > **"Project"**.
   - Cari repository `laporan-pppk` yang anda buat tadi.
   - Tekan **"Deploy"**.

## Tetapan Google Sheets
Pastikan anda menukar URL di dalam fail `services/api.ts` kepada URL **Web App** anda yang dideploy dari Google Apps Script.

---
Dibangunkan untuk kemudahan kakitangan PPPK.
