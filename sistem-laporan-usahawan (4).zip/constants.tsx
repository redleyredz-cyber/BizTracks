
import { Category } from './types';

export const USER_REGISTRY: Record<string, string> = {
  "MOHAMAD RODZHKAIRRIE BIN RAMBLI": "860527135113",
  "MUHAMMAD AFIQ HUSAINI BIN AZMI": "970725025289",
  "NURFAZELA BINTI ARNI": "970704135964",
  "WILTONE KENDAWANG ANAK LANGIT": "931114135663",
  "SHAHRUL NIZAM BIN SABLI": "921003135127",
  "STEVEEN ANAK EDIL": "940718136215",
  "KORINA ANAK JANA": "970525135942",
  "MICHELLE UNYI ANAK HARRY": "980814135796",
  "MOHAMAD SAIFUL BIN AMIN": "881103135999",
  "ASRIZAL BIN RAMLI": "950904135741",
  "MOHAMMAD AZEEREN BIN ALADIN": "990916136115",
  "MOHD FADALIE BIN JAPAR": "970115136029"
};

export const ADMIN_REGISTRY: Record<string, string> = {
  "DIDDIE BIN BUJANG": "diddie5187",
  "NUR AFIQAH BINTI HOSSEN": "afiqah5716"
};

export const PPPK_NAMES = Object.keys(USER_REGISTRY);
export const ADMIN_NAMES = Object.keys(ADMIN_REGISTRY);

export const CATEGORIES: Category[] = ['Usahawan', 'Agromakanan', 'Agro TS'];

export const MONTHS = [
  "Januari", "Februari", "Mac", "April", "Mei", "Jun",
  "Julai", "Ogos", "September", "Oktober", "November", "Disember"
];

export const YEARS = ["2025", "2026", "2027", "2028", "2029", "2030"];

export const PAGE_SIZES = [5, 10, 20, 30, 40, 50];
